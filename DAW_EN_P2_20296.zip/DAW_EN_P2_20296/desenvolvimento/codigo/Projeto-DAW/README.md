
To Do List:

T1 (David) - Adicionar Post (Envia da nossa BD o post criado para a API FluentMe, traduz e guarda numa tabela) - Moderar Posts ex: delete | Opcional: UpVotes-Down Votes

T2 (Tiago) - Traduzir Post (Get Translate da Fluente Me) - Moderar Posts ex: seção de comentários do  delete | Opcional: Acompanhamento e Criação de tópicos

Ambos:
Sistema de Login (Done!)
Analisar dados (Fazer API que vai buscar dados estatisticos)


Implementações para o relatório
- Falar da ISO 27002, no que diz respeito aos utilizadores(passes encriptadas, utilização de passwords faceis para testes, etc..)

