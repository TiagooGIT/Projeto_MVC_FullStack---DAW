<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Post_translated
 *
 * @package App\Models
 *
 * @property int    $id_post_translated     Unique identifier for the translated post.
 * @property int    $id_post                Identifier of the original post.
 * @property int    $id_language            Identifier of the language associated with the translation.
 * @property string $titulo                 Title of the translated post.
 * @property string $conteudo               Content of the translated post.
 * @property int    $validacao              Validation status of the translation (0 for not validated, 1 for validated).
 * @property string $comentario_validacao   Comment associated with the validation status.
 * @property int    $id_user                Identifier of the user who created the translation.
 */
class Post_translated extends Model
{
    use HasFactory;

    /**
     * The connection name for the model.
     *
     * @var string
     */
    protected $connection = 'posts';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'post_translated';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_post_translated';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['id_post', 'id_language', 'titulo', 'conteudo', 'validacao', 'comentario_validacao', 'id_user'];

    /**
     * Get the original post associated with the translation.
     */
    public function post()
    {
        return $this->belongsTo(Post::class, 'id_post', 'id_post');
    }

    /**
     * Get the user who created the translation.
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id_user');
    }

    /**
     * Get the language associated with the translation.
     */
    public function language()
    {
        return $this->belongsTo(Language::class, 'id_language', 'id_language');
    }
}
