<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Class UDVote
 *
 * @package App\Models
 *
 * @property int $id_votes       Unique identifier for the vote.
 * @property int $id_post        Post identifier associated with the vote.
 * @property int $id_user        User identifier who voted.
 * @property string $vote        The vote value ('up' or 'down').
 *
 * @property Post $post          Post relationship associated with the vote.
 * @property User $user          User relationship associated with the vote.
 */
class UDVote extends Model
{
    use HasFactory;

    /**
     * The connection name for the model.
     *
     * @var string
     */
    protected $connection = 'posts';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'ud_votes';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_votes';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['id_post', 'id_user', 'vote'];

    /**
     * Get the post associated with the vote.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function post()
    {
        return $this->belongsTo(Post::class, 'id_post', 'id_post');
    }

    /**
     * Get the user who voted.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id_user');
    }
}
