<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Topic
 *
 * @package App\Models
 *
 * @property int $id_topic              Unique identifier for the topic.
 * @property int $id_user               User identifier who created the topic.
 * @property string $title_topic        Title of the topic.
 * @property string $description_topic  Description of the topic.
 *
 * @property User $user                 User relationship associated with the topic.
 */
class Topic extends Model
{
    use HasFactory;

    /**
     * The connection name for the model.
     *
     * @var string
     */
    protected $connection = 'posts';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'topic';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_topic';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['id_user', 'title_topic', 'description_topic'];

    /**
     * Get the user who created the topic.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id_user');
    }
}
