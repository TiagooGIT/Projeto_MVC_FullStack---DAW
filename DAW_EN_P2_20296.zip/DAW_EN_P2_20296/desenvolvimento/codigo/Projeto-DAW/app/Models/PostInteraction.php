<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Class PostInteraction
 *
 * @package App\Models
 *
 * @property int $id_post_interactions  Unique identifier for the post interaction entry.
 * @property int $id_post               Post identifier associated with the interaction.
 * @property string $action             Action performed during the post interaction.
 *
 * @property Post $post                 Post relationship associated with the interaction.
 */
class PostInteraction extends Model
{
    use HasFactory;

    /**
     * The connection name for the model.
     *
     * @var string
     */
    protected $connection = 'posts';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'post_interactions';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_post_interactions';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['id_post', 'action'];

    /**
     * Get the post associated with the interaction.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function post()
    {
        return $this->belongsTo(Post::class, 'id_post');
    }
}
