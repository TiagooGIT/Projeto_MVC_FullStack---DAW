<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Post
 *
 * @package App\Models
 *
 * @property int    $id_post     Unique identifier for the post.
 * @property string $titulo      Title of the post.
 * @property string $conteudo    Content of the post.
 * @property int    $id_user     Identifier of the user who created the post.
 * @property int    $id_language Identifier of the language associated with the post.
 * @property int    $id_topic    Identifier of the topic associated with the post.
 */
class Post extends Model
{
    use HasFactory;

    /**
     * The connection name for the model.
     *
     * @var string
     */
    protected $connection = 'posts';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'posts';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_post';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['titulo', 'conteudo', 'id_user', 'id_language', 'id_topic'];

    /**
     * Get the user who created the post.
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id_user');
    }

    /**
     * Get the language associated with the post.
     */
    public function language()
    {
        return $this->belongsTo(Language::class, 'id_language', 'id_language');
    }

    /**
     * Get the topic associated with the post.
     */
    public function topic()
    {
        return $this->belongsTo(Topic::class, 'id_topic', 'id_topic');
    }

    /**
     * Get the votes associated with the post.
     */
    public function votes()
    {
        return $this->hasMany(UDVote::class, 'id_post', 'id_post');
    }

    /**
     * Get the interactions associated with the post.
     */
    public function interactions()
    {
        return $this->hasMany(PostInteraction::class, 'id_post');
    }
}
