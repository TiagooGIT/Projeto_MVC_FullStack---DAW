<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Class PostApiId
 *
 * @package App\Models
 *
 * @property int $id_postsAPI_ID          Unique identifier for the API ID entry.
 * @property int $local_post_id           Local post identifier associated with the API ID entry.
 * @property int $api_post_id             API post identifier associated with the API ID entry.
 * @property int $api_translated_post_id  API translated post identifier associated with the API ID entry.
 */
class PostApiId extends Model
{
    use HasFactory;

    /**
     * The connection name for the model.
     *
     * @var string
     */
    protected $connection = 'posts';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'postsAPI_IDs';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_postsAPI_ID';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['local_post_id', 'api_post_id', 'api_translated_post_id'];
}
