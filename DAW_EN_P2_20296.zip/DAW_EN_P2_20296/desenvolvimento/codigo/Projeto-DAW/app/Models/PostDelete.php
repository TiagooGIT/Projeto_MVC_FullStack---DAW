<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Class PostDelete
 *
 * @package App\Models
 *
 * @property int $id_post_delete  Unique identifier for the deleted post entry.
 * @property string $title        Title of the deleted post.
 * @property string $content      Content of the deleted post.
 * @property int $id_user         User identifier associated with the deleted post.
 * @property int $deleted_by      Moderator identifier who deleted the post.
 * @property string $reason       Reason for deleting the post.
 *
 * @property User $user           User relationship associated with the deleted post.
 * @property User $moderator      Moderator relationship who deleted the post.
 */
class PostDelete extends Model
{
    use HasFactory;
    
    /**
     * The connection name for the model.
     *
     * @var string
     */
    protected $connection = 'posts';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'post_deleted';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_post_delete';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['title', 'content', 'id_user', 'deleted_by', 'reason'];

    /**
     * Get the user associated with the deleted post.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user');
    }

    /**
     * Get the moderator associated with the deleted post.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function moderator()
    {
        return $this->belongsTo(User::class, 'deleted_by');
    }
}
