<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Class PostReport
 *
 * @package App\Models
 *
 * @property int $id_post_report    Unique identifier for the post report entry.
 * @property int $id_post           Post identifier associated with the report.
 * @property int $id_user           User identifier who reported the post.
 * @property string $reason         Reason provided for reporting the post.
 *
 * @property Post $post             Post relationship associated with the report.
 */
class PostReport extends Model
{
    use HasFactory;

    /**
     * The connection name for the model.
     *
     * @var string
     */
    protected $connection = 'posts';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'post_report';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_post_report';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['id_post', 'id_user', 'reason'];

    /**
     * Get the post associated with the report.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function post()
    {
        return $this->belongsTo(Post::class, 'id_post', 'id_post');
    }
}
