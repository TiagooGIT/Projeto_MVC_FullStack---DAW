<?php

/**
 * APIFluentMeController.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\API
 *
 * Description: This file contains the APIFluentMeController class, which is responsible for
 * interacting with the Fluent Me API to fetch and store languages, create posts, and translate posts.
 */

namespace App\Http\Controllers\API;

use App\Http\Controllers\WEB\Controller;
use Illuminate\Support\Facades\Http;
use App\Models\Language;

/**
 * Class APIFluentMeController
 *
 * @package App\Http\Controllers\API
 */
class APIFluentMeController extends Controller
{
    /**
     * Fetch and store supported languages from the API.
     */
    public function fetchAndStoreLanguages()
    {
        // Check if there are no languages stored in the database
        if (Language::count() === 0) {
            // Make a request to the API to get supported languages
            $responseLanguages = Http::withHeaders([
                'content-type' => 'application/json',
                'X-RapidAPI-Key' => '2bf2a87011mshe9eb698da18b6dcp1900cejsn7577b285df45',
                'X-RapidAPI-Host' => 'thefluentme.p.rapidapi.com',
            ])->get('https://thefluentme.p.rapidapi.com/language');

            // Extract supported languages from the API response
            $languages = $responseLanguages->json()['supported_languages'];

            // Check if languages array is not empty
            if (!empty($languages)) {
                // Iterate through each language and store it in the database
                foreach ($languages as $language) {
                    $languageName = $language['language_name'];
                    $languageVoice = $language['language_voice'];

                    // Create a new Language model instance and store it in the database
                    Language::create(['language' => $languageName, 'language_voice' => $languageVoice]);
                }
            }
        }
    }

    /**
     * Send a POST request to create a new post.
     *
     * @param string $titulo       The title of the post.
     * @param string $conteudo     The content of the post.
     * @param int    $id_language  The ID of the language for the post.
     *
     * @return mixed
     */
    public function sendPost($titulo, $conteudo, $id_language)
    {
        // Make a POST request to create a new post
        $response = Http::withHeaders([
            'content-type' => 'application/json',
            'X-RapidAPI-Key' => '2bf2a87011mshe9eb698da18b6dcp1900cejsn7577b285df45',
            'X-RapidAPI-Host' => 'thefluentme.p.rapidapi.com',
        ])->post('https://thefluentme.p.rapidapi.com/post', [
            'post_language_id' => $id_language,
            'post_title' => $titulo,
            'post_content' => $conteudo,
        ]);

        return $response;
    }

    /**
     * Send a POST request to translate a post.
     *
     * @param int $api_post_id     The ID of the post on the API.
     * @param int $id_language     The ID of the target language for translation.
     *
     * @return mixed
     */
    public function sendPostToTranslate($api_post_id, $id_language)
    {
        // Make a POST request to translate a post
        $response = Http::withHeaders([
            'content-type' => 'application/json',
            'X-RapidAPI-Key' => '2bf2a87011mshe9eb698da18b6dcp1900cejsn7577b285df45',
            'X-RapidAPI-Host' => 'thefluentme.p.rapidapi.com',
        ])->post('https://thefluentme.p.rapidapi.com/translate/' . $api_post_id, [
            'target_language_id' => $id_language,
        ]);

        return $response;
    }
}
