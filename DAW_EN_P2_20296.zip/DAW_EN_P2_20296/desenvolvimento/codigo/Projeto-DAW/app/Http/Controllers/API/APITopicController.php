<?php
/**
 * APITopicController.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\API
 *
 * Description: This file contains the APITopicController class, which is responsible for
 * handling CRUD operations for topics, including fetching, creating, updating, and deleting.
 */

namespace App\Http\Controllers\API;

use App\Models\Topic;
use Illuminate\Http\Request;
use App\Http\Controllers\WEB\Controller as Controller;

/**
 * Class APITopicController
 *
 * @package App\Http\Controllers\API
 */
class APITopicController extends Controller
{
    /**
     * Retrieve all topics.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $topics = Topic::all();
        return response()->json($topics);
    }

    /**
     * Retrieve details of a specific topic.
     *
     * @param int $id The ID of the topic.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $topic = Topic::findOrFail($id);
        return response()->json($topic);
    }

    /**
     * Create a new topic.
     *
     * @param Request $request The HTTP request.
     *
     * @return \Illuminate\Http\JsonResponse
     */

    public function store(Request $request)
    {
        $topic = Topic::create($request->all());
        return response()->json($topic, 201);
    }

    /**
     * Update an existing topic.
     *
     * @param Request $request The HTTP request.
     * @param int     $id      The ID of the topic.
     *
     * @return \Illuminate\Http\JsonResponse
     */

    public function update(Request $request, $id)
    {
        $topic = Topic::findOrFail($id);
        $topic->update($request->all());
        return response()->json($topic, 200);
    }

    /**
     * Delete a topic.
     *
     * @param int $id The ID of the topic.
     *
     * @return \Illuminate\Http\JsonResponse
     */

    public function destroy($id)
    {
        $topic = Topic::findOrFail($id);
        $topic->delete();
        return response()->json(null, 204);
    }
}
