<?php
/**
 * WebUDVoteController.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\WEB
 * 
 * Description: This file contains the WebUDVoteController class, which handles user votes on posts.
 */

namespace App\Http\Controllers\WEB;

use App\Http\Controllers\WEB\Controller;
use App\Models\UDVote;
use App\Models\Post;
use Illuminate\Http\Request;

/**
 * Class WebUDVoteController
 *
 * @package App\Http\Controllers\WEB
 */
class WebUDVoteController extends Controller
{
    /**
     * Vote on a post (upvote or downvote).
     *
     * @param Request $request The HTTP request.
     * @param int     $postId   The ID of the post to vote on.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function vote(Request $request, $postId)
    {
        $post = Post::find($postId);
        $user = auth()->user();
        $vote = $request->input('vote');

        // Check if the vote is valid (either 'up' or 'down')
        if (!in_array($vote, ['up', 'down'])) 
        {
            return redirect()->back()->with('error', 'Voto inválido.');
        }

        // Check if the user has already voted on this post
        $existingVote = UDVote::where('id_post', $post->id_post)
            ->where('id_user', $user->id_user)
            ->first();

        // Update or create the user's vote
        if ($existingVote) {
            if ($existingVote->vote === $vote) {
                $existingVote->delete(); // Remove the vote if it matches the current vote
            } else {
                $existingVote->update(['vote' => $vote]); // Update the vote if it's different
            }
        } else {
            // Create a new vote if the user hasn't voted on this post before
            UDVote::create([
                'id_user' => $user->id_user,
                'id_post' => $post->id_post,
                'vote' => $vote,
            ]);
        }

        return redirect()->back()->with('success', 'Voto registrado com sucesso.');
    }
}
