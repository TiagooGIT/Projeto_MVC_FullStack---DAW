<?php
/**
 * ModController.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\WEB
 *
 * Description: This file contains the ModController class, which is responsible for
 * handling moderation-related operations on the web interface, such as viewing, validating,
 * and deleting posts.
 */

namespace App\Http\Controllers\WEB;

use App\Http\Controllers\WEB\Controller;
use App\Http\Controllers\API\APIModController;
use Illuminate\Http\Request;

/**
 * Class ModController
 *
 * @package App\Http\Controllers\WEB
 */
class ModController extends Controller
{
    /**
     * Display moderation information for a specific post.
     *
     * @param int $postId The ID of the post.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function moderation($postId)
    {
        $apiModController = new APIModController();
        $response = $apiModController->moderation($postId);
        $post = $response->original['data'];
        return view('mod.moderation', compact('post'));
    }

    /**
     * Display moderated translations for a specific post.
     *
     * @param int $postId The ID of the post.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function moderations_translation($postId)
    {
        $apiModController = new APIModController();
        $response = $apiModController->moderations_translation($postId);
        $posts_translated = $response->original['data'];
        return view('mod.moderation_Translation', compact('posts_translated'));
    }

    /**
     * Display validation information for a specific post translation.
     *
     * @param int $postId The ID of the post.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function validateById($postId)
    {
        $apiModController = new APIModController();
        $response = $apiModController->validateById($postId);
        $posts_translated = $response->original['data'];
        return view('mod.validation', compact('posts_translated'));
    }

    /**
     * Validate a specific post translation.
     *
     * @param Request          $request          The HTTP request.
     * @param int              $postId           The ID of the post.
     * @param APIModController $apiModController An instance of the APIModController.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function validate_Translation(Request $request, $postId, APIModController $apiModController)
    {
        $apiResponse = $apiModController->Validation($request, $postId);

        if ($apiResponse->getStatusCode() == 201) {
            return redirect()->route('posts.moderation_translation', ['id' => $postId])->with('success', 'Validação Executada com Sucesso.');
        } else {
            return redirect()->route('home')->with('error', 'Falha ao eliminar o post.');
        }
    }

    /**
     * Display deletion confirmation for a specific post.
     *
     * @param int $postId The ID of the post.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function delete($postId)
    {
        $apiModController = new APIModController();
        $response = $apiModController->delete($postId);
        $post = $response->original['data'];

        return view('mod.delete', compact('post'));
    }
    /**
     * Delete a specific post.
     *
     * @param Request          $request          The HTTP request.
     * @param int              $postId           The ID of the post.
     * @param APIModController $apiModController An instance of the APIModController.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deletePost(Request $request, $postId, APIModController $apiModController)
    {
        $apiResponse = $apiModController->deletePost($request, $postId);
        if ($apiResponse->getStatusCode() == 201) {
            return redirect()->route('home')->with('success', 'Post eliminado com sucesso.');
        } else {
            return redirect()->route('home')->with('error', 'Falha ao eliminar o post.');
        }
    }

    /**
     * Display the moderator dashboard.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function dashboard()
    {
        $apiModController = new APIModController();
        $response = $apiModController->dashboard();
        $deletedPosts = $response->original['data'];
    
        return view('dashboard.moderator.moderator', compact('deletedPosts'));
    }

    /**
     * Display reported posts.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function reports()
    {
        $apiModController = new APIModController();
        $response = $apiModController->reports();
        $reportedPosts = $response->original['data'];

        return view('dashboard.moderator.reports', compact('reportedPosts'));
    }
}
