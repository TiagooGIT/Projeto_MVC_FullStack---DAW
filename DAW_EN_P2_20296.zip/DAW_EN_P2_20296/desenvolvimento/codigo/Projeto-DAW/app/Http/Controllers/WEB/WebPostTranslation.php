<?php
/**
 * WebPostTranslation.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\WEB
 *
 * Description: This file contains the WebPostTranslation class, which is responsible for
 * handling web interface operations related to translated posts, such as displaying, creating,
 * updating, and deleting translations.
 */

namespace App\Http\Controllers\WEB;

use Illuminate\Http\Request;
use App\Http\Controllers\API\APIPostTranslatedController as apiTranslatedPost;

/**
 * Class WebPostTranslation
 *
 * @package App\Http\Controllers\WEB
 */
class WebPostTranslation extends controller
{
    /**
     * Display a listing of the translated posts.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function index()
    {
        $apiController = new apiTranslatedPost();
        $response = $apiController->index();

        return $this->handleApiResponse($response);
    }

    /**
     * Show the specified translated post.
     *
     * @param int $id The ID of the translated post.
     *
     * @return \Illuminate\Contracts\View\View
     */

    public function show($id)
    {
        $apiController = new apiTranslatedPost();
        $response = $apiController->show();
        $postTranslated = $response->original['data'];

        return view('translations.showTranslation', compact('postTranslated'));
    }

    /**
     * Show the form for creating a new translated post.
     *
     * @return \Illuminate\Contracts\View\View
     */

    public function create()
    {
        return view('postsTranslation.create');
    }

    /**
     * Store a newly created translated post in storage.
     *
     * @param Request $request The HTTP request.
     * @param int     $id      The ID of the original post.
     *
     * @return \Illuminate\Http\RedirectResponse
     */

    public function store(Request $request, $id)
    {
        $apiController = new apiTranslatedPost();
        $response = $apiController->store($request,$id);
        
        if ($response ->getStatusCode() >= 200 && $response ->getStatusCode() < 300) {
            return redirect()->route('translations.showTranslation',$id)->with('success', 'Tradução Criada com Sucesso');
        } else {
            return redirect()->route('home')->with('error', 'Erro ao criar post ou enviar para a API.');
        }
    }

    /**
     * Show the form for editing the specified translated post.
     *
     * @param int $id The ID of the translated post.
     *
     * @return \Illuminate\Contracts\View\View
     */

    public function edit($id)
    {
        $apiController = new apiTranslatedPost();
        $response = $apiController->edit($id);

        return $this->handleApiResponse($response);
    }

    /**
     * Update the specified translated post in storage.
     *
     * @param Request $request The HTTP request.
     * @param int     $id      The ID of the translated post.
     *
     * @return \Illuminate\Http\RedirectResponse
     */

    public function update(Request $request, $id)
    {
        $apiController = new apiTranslatedPost();
        $response = $apiController->update($request, $id);

        return $this->handleApiResponse($response);
    }

    /**
     * Remove the specified translated post from storage.
     *
     * @param int $id The ID of the translated post.
     *
     * @return \Illuminate\Http\RedirectResponse
     */

    public function destroy($id)
    {
        $apiController = new apiTranslatedPost();
        $response = $apiController->destroy($id);

        return $this->handleApiResponse($response);
    }


}