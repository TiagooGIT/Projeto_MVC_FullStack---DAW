<?php
/**
 * WebPostController.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\WEB
 *
 * Description: This file contains the WebPostController class, which is responsible for
 * handling web interface operations related to posts, such as displaying, creating, updating,
 * reporting, and showing graphs.
 */

namespace App\Http\Controllers\WEB;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Language;
use App\Models\PostInteraction;

use App\Http\Controllers\API\APIPostController;

/**
 * Class WebPostController
 *
 * @package App\Http\Controllers\WEB
 */
class WebPostController extends controller
{

    /**
     * Display a listing of the posts.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function index()
    {
        $apiController = new ApiPostController(); 
        $response = $apiController->index(); 
        $posts = $response->original['data']; 
        return view('home', compact('posts')); 
    }

    /**
     * Show the form for creating a new post.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function create()
    {
        $apiController = new ApiPostController(); 
        $response = $apiController->create(); 
        $languages = $response->original['data'];
        return view('posts.create', compact('languages'));
    }

    /**
     * Store a newly created post in storage.
     *
     * @param Request $request The HTTP request.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $apiController = new ApiPostController();
        $apiResponse = $apiController->store($request);

        if ($apiResponse->getStatusCode() >= 200 && $apiResponse->getStatusCode() < 300) {
            return redirect()->route('home')->with('success', 'Post criado e enviado para a API com sucesso!');
        } else {
            return redirect()->route('home')->with('error', 'Erro ao criar post ou enviar para a API.');
        }
    }

    /**
     * Display the specified post.
     *
     * @param int $id The ID of the post.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function show($id)
    {
        $languages = Language::all();
        $apiController = new ApiPostController();
        $response = $apiController->show($id);
        $post = $response->original['data'];
        $posts_translated = $response->original['data2'];
        $isOwner = auth()->check() && auth()->user()->id_user === $post->user->id_user;

        if (!$isOwner) {
            $post->interactions()->create(['action' => 'view_more']);
        }

        return view('posts.show', compact('post', 'languages', 'posts_translated'));
    }

    /**
     * Show the form for editing the specified post.
     *
     * @param int $id The ID of the post.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function edit($id)
    {
        $apiController = new ApiPostController();
        $response = $apiController->show($id);
        $post = $response->original['data'];
        return view('posts.edit', compact('post'));
    }

    /**
     * Update the specified post in storage.
     *
     * @param Request $request The HTTP request.
     * @param int     $id      The ID of the post.
     *
     * @return \Illuminate\Http\RedirectResponse
     */

    public function update(Request $request, $id)
    {
        $apiController = new ApiPostController();
        $apiResponse = $apiController->update($request, $id);

        if ($apiResponse->getStatusCode() >= 200 && $apiResponse->getStatusCode() < 300) {
            return redirect()->route('home')->with('success', 'Post atualizado com sucesso!');
        } else {
            return redirect()->route('home')->with('error', 'Erro ao atualizar post');
        }
    }

    /**
     * Show the form for reporting the specified post.
     *
     * @param int $postId The ID of the post.
     *
     * @return \Illuminate\Contracts\View\View
     */

    public function report($postId)
    {
        $apiController = new ApiPostController();
        $response = $apiController->report($postId);
        $post = $response->original['data'];
        return view('posts.report', compact('post'));

    }

    /**
     * Report the specified post.
     *
     * @param Request $request The HTTP request.
     * @param int     $postId   The ID of the post.
     *
     * @return \Illuminate\Http\RedirectResponse
     */

    public function reportPost(Request $request, $postId)
    {
        $apiController = new ApiPostController();
        $response = $apiController->reportPost($request, $postId);
        return redirect()->route('home')->with('success', 'Post reportado com sucesso.');
    }

    /**
     * Show the graph for the specified post and metric.
     *
     * @param Request $request The HTTP request.
     * @param int     $id      The ID of the post.
     *
     * @return \Illuminate\Contracts\View\View
     */

    public function showGraph(Request $request, $id)
    {
        $post = Post::find($id);
        $metric = $request->input('metric', 'view_more', 'report', 'tradução', 'tradução_validada', 'tradução_eliminada');
        $interactions = PostInteraction::where('id_post', $id)
            ->where('action', $metric)
            ->get();
            
        $clicks = $interactions->groupBy(function ($interaction) {
            return $interaction->created_at->format('d-m-Y');
        })->map->count();

        $labels = $clicks->keys()->toArray();

        return view('posts.graph', compact('labels', 'clicks', 'post', 'metric'));
    }
}
