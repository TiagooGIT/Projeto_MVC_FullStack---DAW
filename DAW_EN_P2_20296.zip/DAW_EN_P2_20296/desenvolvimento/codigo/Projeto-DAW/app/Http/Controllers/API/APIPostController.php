<?php
/**
 * APIPostController.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\API
 *
 * Description: This file contains the APIPostController class, which is responsible for
 * handling CRUD operations for posts, including fetching, creating, updating, and reporting posts.
 */

namespace App\Http\Controllers\API;

use App\Models\Post;
use App\Models\PostApiId;
use App\Models\Post_translated;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\PostReport;
use App\Models\Language;
use App\Http\Controllers\WEB\Controller;
use App\Http\Controllers\API\APIFluentMeController;

/**
 * Class APIPostController
 *
 * @package App\Http\Controllers\API
 */
class APIPostController extends Controller
{
    /**
     * Retrieve all posts.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(): \Illuminate\Http\JsonResponse
    {
        $posts = Post::all();
        return response()->json(['data' => $posts]);
    }

    /**
     * Retrieve details of a specific post and its translations.
     *
     * @param int $id The ID of the post.
     *
     * @return \Illuminate\Http\JsonResponse
     */

    public function show($id): \Illuminate\Http\JsonResponse
    {
        $post = Post::findOrFail($id);
        $posts_translated = Post_translated::where('id_post', $id)->get();

        return response()->json(['data' => $post, 'data2' => $posts_translated]);
    }

     /**
     * Create a new post.
     *
     * @param Request $request The HTTP request.
     *
     * @return \Illuminate\Http\JsonResponse
     */

    public function store(Request $request): \Illuminate\Http\JsonResponse
    {
        $request->validate([
            'titulo' => 'required',
            'conteudo' => 'required',
            'id_language' => 'required|numeric',
        ]);
        $user = Auth::user();
        $post = $user->posts()->create([
            'titulo' => $request->titulo,
            'conteudo' => $request->conteudo,
            'id_language' => $request->id_language,
        ]);

        $apiFluentMeController = new APIFluentMeController();
        $apiResponse = $apiFluentMeController->sendPost($request->titulo, $request->conteudo, $request->id_language);

        if ($apiResponse->successful()) {
            $apiPostId = json_decode($apiResponse->body())->post_id;

            PostApiId::create([
                'local_post_id' => $post->id_post,
                'api_post_id' => $apiPostId,
            ]);

            return response()->json(['data' => $post], 201);
        } else {
            return response()->json(['error' => 'Erro ao enviar post para a API.'], $apiResponse->status());
        }
    }

    /**
     * Update an existing post.
     *
     * @param Request $request The HTTP request.
     * @param int     $id      The ID of the post.
     *
     * @return \Illuminate\Http\JsonResponse
     */

    public function update(Request $request, $id): \Illuminate\Http\JsonResponse
    {
        $request->validate([
            'titulo' => 'required',
            'conteudo' => 'required',
        ]);

        $user = Auth::user();
        $post = $user->posts()->findOrFail($id);
        $post->update([
            'titulo' => $request->titulo,
            'conteudo' => $request->conteudo,
        ]);

        return response()->json(['data' => $post]);
    }

    /**
     * Report a post.
     *
     * @param int $postId The ID of the post.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function report($postId): \Illuminate\Http\JsonResponse
    {
        $post = Post::findOrFail($postId);

        return response()->json(['data' => $post], 201);
    }

    /**
    * Retrieve available languages for creating a new post.
    *
    * @return \Illuminate\Http\JsonResponse
    */

    public function create(): \Illuminate\Http\JsonResponse
    {
        $languages = Language::all();
        return response()->json(['data' => $languages], 201);
    }
    
    /**
     * Report a post with a reason.
     *
     * @param Request $request The HTTP request.
     * @param int     $postId   The ID of the post.
     *
     * @return \Illuminate\Http\JsonResponse
     */

    public function reportPost(Request $request, $postId): \Illuminate\Http\JsonResponse
    {
        $request->validate([
            'reason' => 'required|string',
        ]);

        $post = Post::find($postId);
        $user = auth()->user();

        if (!$post) {
            return response()->json(['error' => 'Post não encontrado.']);
        }

        if (!$user) {
            return response()->json(['error' =>  'User não autenticado.']);
        }

        $isOwner = auth()->check() && auth()->user()->id_user === $post->user->id_user;

        if (!$isOwner) {
            $post->interactions()->create(['action' => 'report']);
        }

        PostReport::create([
            'id_post' => $post->id_post,
            'id_user' => $user->id_user,
            'reason' => $request->input('reason'),
        ]);

        return response()->json(['data'], 201);

    }
}
