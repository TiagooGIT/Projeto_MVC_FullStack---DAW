<?php
/**
 * TopicTranslationController.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\WEB
 *
 * Description: This file contains the TopicTranslationController class, which is responsible for
 * handling CRUD operations for topic translations on the web interface.
 */

namespace App\Http\Controllers\WEB;

use Illuminate\Http\Request;
use App\Http\Controllers\API\APITopicController as ApiTopicController;

/**
 * Class TopicTranslationController
 *
 * @package App\Http\Controllers\WEB
 */

class TopicTranslationController extends Controller
{
    /**
     * Display a listing of the topic translations.
     *
     * @return mixed
     */
    public function index()
    {
        $apiController = new ApiTopicController();
        $response = $apiController->index();

        return $this->handleApiResponse($response);
    }

    /**
     * Display the specified topic translation.
     *
     * @param int $id The ID of the topic translation.
     *
     * @return mixed
     */
    public function show($id)
    {
        $apiController = new ApiTopicController();
        $response = $apiController->show($id);

        return $this->handleApiResponse($response);
    }

    /**
     * Show the form for creating a new topic translation.
     *
     * @return mixed
     */

    public function create()
    {
        return view('topicsTranslation.create');
    }

    /**
     * Store a newly created topic translation in storage.
     *
     * @param Request $request The HTTP request.
     *
     * @return mixed
     */

    public function store(Request $request)
    {
        $apiController = new ApiTopicController();
        $response = $apiController->store($request);

        return $this->handleApiResponse($response);
    }

    /**
     * Show the form for editing the specified topic translation.
     *
     * @param int $id The ID of the topic translation.
     *
     * @return mixed
     */

    public function edit($id)
    {
        $apiController = new ApiTopicController();
        $response = $apiController->edit($id);

        return $this->handleApiResponse($response);
    }

    /**
     * Update the specified topic translation in storage.
     *
     * @param Request $request The HTTP request.
     * @param int     $id      The ID of the topic translation.
     *
     * @return mixed
     */
    public function update(Request $request, $id)
    {
        $apiController = new ApiTopicController();
        $response = $apiController->update($request, $id);

        return $this->handleApiResponse($response);
    }

    /**
     * Remove the specified topic translation from storage.
     *
     * @param int $id The ID of the topic translation.
     *
     * @return mixed
     */

    public function destroy($id)
    {
        $apiController = new ApiTopicController();
        $response = $apiController->destroy($id);

        return $this->handleApiResponse($response);
    }

    /**
     * Handle the API response and redirect accordingly.
     *
     * @param mixed $response The API response.
     *
     * @return mixed
     */

    private function handleApiResponse($response)
    {
        if ($response->getStatusCode() == 200) {
            $data = $response->original['data'];

            return view('home', compact('data'));
        } else {
            return redirect()->route('error.page')->with('error', 'Failed to fetch data from API');
        }
    }
}
