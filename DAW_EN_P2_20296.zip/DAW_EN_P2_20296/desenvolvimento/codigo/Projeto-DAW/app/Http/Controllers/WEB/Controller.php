<?php
/**
 * Controller.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\WEB
 *
 * Description: This file contains the base Controller class for web controllers,
 * which includes traits for authorizing requests and validating requests.
 */

namespace App\Http\Controllers\WEB;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

/**
 * Class Controller
 *
 * @package App\Http\Controllers\WEB
 */
class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;
}
