<?php
/**
 * UserController.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\WEB
 *
 * Description: This file contains the UserController class, which is responsible for
 * handling user-related operations on the web interface, such as displaying the user dashboard.
 */

namespace App\Http\Controllers\WEB;

use App\Http\Controllers\WEB\Controller;
use Illuminate\Support\Facades\Auth;

/**
 * Class UserController
 *
 * @package App\Http\Controllers\WEB
 */
class UserController extends Controller
{
    /**
     * Display the user dashboard.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function dashboard()
    {
        $user = Auth::user();
        $userPosts = $user->posts()->with('votes')->get();
        return view('dashboard.user', compact('userPosts'));
    }
}
