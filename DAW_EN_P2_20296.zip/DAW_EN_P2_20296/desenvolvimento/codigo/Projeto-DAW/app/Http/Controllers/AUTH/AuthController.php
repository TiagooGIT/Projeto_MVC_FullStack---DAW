<?php
/**
 * AuthController.php
 *
 * PHP version 7.0
 *
 * @category    Controller
 * @package     App\Http\Controllers\AUTH
 * @author      Your Name
 * @license     https://opensource.org/licenses/MIT MIT License
 * @link        Your GitHub repository link or other relevant link
 *
 * Description: This file contains the AuthController class, which is responsible for
 * handling user authentication, including sign-in, sign-up, and logout.
 */

namespace App\Http\Controllers\AUTH;

use Illuminate\Http\Request;
use App\Http\Controllers\AUTH\BaseController as BaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

/**
 * Class AuthController
 *
 * @package App\Http\Controllers\AUTH
 */
class AuthController extends BaseController
{
    /**
     * Attempt to sign in the user.
     *
     * @param Request $request The HTTP request.
     *
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function signin(Request $request)
    {
        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            $authUser = Auth::user();
            $success['token'] =  $authUser->createToken('MyAuthApp')->plainTextToken;
            $success['name'] =  $authUser->name;

            return redirect()->route('home');
        } else {
            return $this->sendError('Unauthorised.', ['error' => 'Unauthorised']);
        }
    }
    
    /**
     * Attempt to sign up a new user.
     *
     * @param Request $request The HTTP request.
     *
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function signup(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required',
            'confirm_password' => 'required|same:password',
        ]);
        if ($validator->fails()) {
            return $this->sendError('Error validation', $validator->errors());
        }

        $input = $request->all();
        $input['password'] = bcrypt($input['password']);
        
        $input['moderator'] = $request->has('moderator');
        $user = User::create($input);
        $success['token'] =  $user->createToken('MyAuthApp')->plainTextToken;
        $success['name'] =  $user->name;

        return redirect('login')->with('success', 'User created successfully. Please log in.');
    }

    /**
     * Logout the authenticated user.
     *
     * @param Request $request The HTTP request.
     *
     * @return \Illuminate\Http\RedirectResponse
     */

    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
    
    /**
     * Show the login form.
     *
     * @return \Illuminate\Contracts\View\View
     */

    public function showLoginForm()
    {
        return view('auth.login');
    }

    /**
     * Show the registration form.
     *
     * @return \Illuminate\Contracts\View\View
     */

    public function showRegisterForm()
    {
        return view('auth.register');
    }

}