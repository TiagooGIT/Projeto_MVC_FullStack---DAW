<?php
/**
 * Command to fetch and store languages.
 *
 * PHP version 7.0
 *
 * @category Console_Command
 * @package  App\Console\Commands
 */
namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Http\Controllers\API\APIFluentMeController;

/**
 * Class FetchLanguages
 *
 * @package App\Console\Commands
 */
class FetchLanguages extends Command
{
    /**
     * The console command signature.
     *
     * @var string
     */
    protected $signature = 'fetch:languages';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch and store languages';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // Instantiate the controller
        $fluentMeController = new APIFluentMeController();

        // Call the function to fetch and store languages
        $fluentMeController->fetchAndStoreLanguages();

        // Display success message
        $this->info('Languages fetched and stored successfully.');
    }
}


//Utilizar este comando composer dump-autoload primeiro 
//Usar este comando php artisan fetch:languages para ir buscar as linguas á Fluent